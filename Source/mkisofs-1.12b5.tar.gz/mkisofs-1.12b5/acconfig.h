/* Definitions for mkisofs processed by autoheader. */

#undef NODIR                    /* none -- don't make numbered backup files */

/* This shows us where to find the major()/minor() macros */
#undef MAJOR_IN_MKDEV
#undef MAJOR_IN_SYSMACROS
